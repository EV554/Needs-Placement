const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true
}));

const membersFilePath = path.join(__dirname, 'members.json');

// Load members from file
let members = [];
if (fs.existsSync(membersFilePath)) {
    members = JSON.parse(fs.readFileSync(membersFilePath, 'utf-8'));
}

// Admin credentials
const adminCredentials = {
    loginId: 'Needs Placement',
    password: '$1Shreeraj1$',
    securityAnswer: 'VIBGYOR' // Updated security answer
};

// Admin login page
app.get('/admin-login.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public/admin-login.html'));
});

// Verify admin credentials and redirect to security question
app.post('/verify-security-question.html', (req, res) => {
    const { 'admin-id': adminId, 'admin-password': adminPassword } = req.body;
    if (adminId === adminCredentials.loginId && adminPassword === adminCredentials.password) {
        req.session.authenticated = true;
        res.sendFile(path.join(__dirname, 'public/verify-security-question.html'));
    } else {
        res.status(401).send('Unauthorized');
    }
});

// Verify security question and redirect to admin dashboard
app.post('/admin-dashboard.html', (req, res) => {
    const { 'security-question': securityAnswer } = req.body;
    if (req.session.authenticated && securityAnswer.toUpperCase() === adminCredentials.securityAnswer.toUpperCase()) {
        res.sendFile(path.join(__dirname, 'public/admin-dashboard.html'));
    } else {
        res.status(401).send('Unauthorized');
    }
});

// Manage members (add/remove)
app.post('/manage-members.html', (req, res) => {
    const { name, email, 'login-id': loginId, password, 'remove-login-id': removeLoginId } = req.body;

    if (loginId && password) {
        // Add new member
        members.push({ name, email, loginId, password });
    } else if (removeLoginId) {
        // Remove member
        members = members.filter(member => member.loginId !== removeLoginId);
    }

    // Save members to file
    fs.writeFileSync(membersFilePath, JSON.stringify(members, null, 2));

    res.sendFile(path.join(__dirname, 'public/admin-dashboard.html'));
});

// Serve static files (e.g., HTML, CSS)
app.use(express.static(path.join(__dirname, 'public')));

app.listen(3000, () => {
    console.log('Server is running on http://localhost:3000');
});